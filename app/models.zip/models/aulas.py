"""
================================================================================
AULAS.PY - Frequência e diário de aula
================================================================================

Contém:
    - Frequencia   : pauta (presença/falta por aluno/dia/turma).
    - RegistroAula : diário do professor (o que foi dado no dia).

São a base operacional da rotina pedagógica.
================================================================================
"""

from app.models.base import db, datetime, hybrid_property, get_local_now


class Frequencia(db.Model):
    """
    Registro unitário de presença/falta de um aluno em uma turma em um dia.

    Conceitos (`conceito`):
        A, B, C, D -> presença (com gradações qualitativas)
        F          -> falta
        J          -> falta justificada (não conta para frequência)

    A property `presente` é híbrida: pode ser usada em Python e em queries
    SQL (`.filter(Frequencia.presente.is_(True))`).
    """
    __tablename__ = 'frequencia'

    id: int = db.Column(db.Integer, primary_key=True)
    aluno_id: int = db.Column(db.Integer, db.ForeignKey('aluno.id'), nullable=False)
    turma_id: int = db.Column(db.Integer, db.ForeignKey('turma.id'), nullable=False)
    data: str = db.Column(db.String(20), nullable=False)  # YYYY-MM-DD (dívida técnica)
    conceito: str = db.Column(db.String(1))               # A, B, C, D, F, J

    unidade_id: int = db.Column(db.Integer, db.ForeignKey('unidade.id'), nullable=True)
    unidade = db.relationship('Unidade', backref='frequencias')

    @hybrid_property
    def presente(self) -> bool:
        """True se o conceito indica presença (A/B/C/D)."""
        return self.conceito in ['A', 'B', 'C', 'D']

    @presente.expression
    def presente(cls):
        """Versão SQL da property `presente` (para uso em filtros)."""
        return cls.conceito.in_(['A', 'B', 'C', 'D'])


class RegistroAula(db.Model):
    """
    Diário de aula: o que o professor registrou em uma turma em um dia.

    Guarda o tema trabalhado (`tema_id`), observações livres, e o instrutor
    responsável. É a base para o acompanhamento pedagógico.

    Notas:
        - `data` é STRING `YYYY-MM-DD` (dívida técnica).
        - `turma_rel` é o nome do relacionamento com Turma; o backref `diarios`
          está no lado da Turma.
    """
    __tablename__ = 'registro_aula'

    id: int = db.Column(db.Integer, primary_key=True)
    turma_id: int = db.Column(db.Integer, db.ForeignKey('turma.id'), nullable=False)
    data: str = db.Column(db.String(20), nullable=False)  # YYYY-MM-DD
    tema_id: int = db.Column(db.Integer, db.ForeignKey('tema_aula.id'), nullable=True)
    observacoes: str = db.Column(db.Text)
    instrutor_id: int = db.Column(db.Integer, db.ForeignKey('user.id'))
    created_at: datetime = db.Column(db.DateTime, default=get_local_now)

    unidade_id: int = db.Column(db.Integer, db.ForeignKey('unidade.id'), nullable=True)
    unidade = db.relationship('Unidade', backref='diarios_unidade')
    turma_rel = db.relationship('Turma', backref='diarios')
    tema = db.relationship('TemaAula', foreign_keys=[tema_id])
    instrutor = db.relationship('User', foreign_keys=[instrutor_id])