# MER — Modelo Entidade-Relacionamento

> Documento vivo do esquema do banco de dados. **Atualize sempre que criar,
> alterar ou remover uma tabela/coluna.** Cada alteração deve vir acompanhada
> da migration correspondente.

---

## Sumário

1. [Visão geral](#1-visão-geral)
2. [Estrutura do pacote de modelos](#2-estrutura-do-pacote-de-modelos)
3. [Glossário](#3-glossário)
4. [Multitenancy](#4-multitenancy)
5. [Mapa de domínios](#5-mapa-de-domínios)
6. [Diagramas ER por domínio](#6-diagramas-er-por-domínio)
7. [Dicionário de dados](#7-dicionário-de-dados)
8. [Regras de negócio transversais](#8-regras-de-negócio-transversais)
9. [Convenções de código](#9-convenções-de-código)
10. [Dívida técnica e roadmap](#10-dívida-técnica-e-roadmap)

---

## 1. Visão geral

O sistema é um **ERP socioeducativo** multitenant, organizado em torno de
**unidades** (tenants). Cada unidade possui:

- Usuários próprios (professores, pedagogia, secretaria).
- Catálogo próprio de cursos, níveis e turmas.
- Períodos letivos, calendário e conselhos de classe.
- Alunos e seus atendimentos (pedagógicos e de serviço social).

**Banco:** PostgreSQL (produção) / SQLite (testes locais).
**ORM:** SQLAlchemy via Flask-SQLAlchemy.
**Fonte de verdade do código:** `app/models/` (pacote).
**Fonte de verdade do esquema:** este documento.

---

## 2. Estrutura do pacote de modelos

O antigo `models.py` monolítico foi dividido por **domínio de negócio**:

```text
app/models/
├── __init__.py            # Reexporta tudo (compatibilidade)
├── base.py                # Imports comuns + convenções (não define modelos)
├── organizacao.py         # Unidade, ConfiguracaoSistema
├── usuarios.py            # User
├── pedagogico.py          # Curso, Nivel
├── academico.py           # PeriodoLetivo, Turma, TemaAula
├── pessoas.py             # Aluno, SituacaoEscolar
├── matriculas.py          # Inscricao, Transferencia
├── calendario.py          # DiaBloqueado, DiaBloqueadoTurma
├── aulas.py               # Frequencia, RegistroAula
├── conselho.py            # PeriodoConselho, PerguntaConselho,
│                          # OpcaoProximaTurma, ConselhoClasse, ConselhoResposta
├── atendimento.py         # Atendimento
├── servico_social.py      # AgendaServicoSocial, RespostaFormulario
├── auditoria.py           # LogAcao
└── legado.py              # Registro
```

**Regras de importação:**

1. Código **fora** do pacote importa sempre de `app.models` (não dos módulos
   internos). Ex.: `from app.models import Aluno, Turma`.
2. Código **dentro** do pacote importa pelo caminho completo do módulo
   (ex.: `from app.models.pessoas import Aluno`) para evitar importação
   parcial durante o carregamento de `__init__.py`.
3. Dentro de **métodos**, quando precisar de outro modelo, use import local
   (`from app.models.aulas import Frequencia`) para não criar ciclos.

---

## 3. Glossário

| Termo | Significado |
|---|---|
| **Unidade** | Tenant do sistema. Fronteira de isolamento de dados. |
| **Turma** | Agrupamento operacional de alunos em um curso/período. |
| **Inscrição** | Vínculo N:N entre Aluno e Turma, com histórico. |
| **Conceito** | Código de presença/falta: `A`,`B`,`C`,`D` (presente), `F` (falta), `J` (justificada). |
| **Conselho de Classe** | Reunião colegiada que avalia aluno/turma por etapa. |
| **Etapa** | Momento do conselho: `INICIAL`, `PERCURSO`, `FINAL`. |
| **Tema de Aula** | Tópico macro do planejamento pedagógico. |
| **Dia bloqueado** | Data sem aula em um período letivo (feriado, etc.). |

---

## 4. Multitenancy

A coluna **`unidade_id`** aparece em quase todas as tabelas de negócio.

Regras:

1. **Toda consulta de listagem deve filtrar por `unidade_id`** do usuário logado,
   exceto para o perfil `admin` global.
2. `Unidade` **não** é apagada se houver registros dependentes (integridade).
3. `User.email` é único **globalmente** (não por unidade).
4. `ConfiguracaoSistema.unidade_id = NULL` significa configuração **global**.
5. `Nivel.nome` é único **globalmente** hoje (dívida técnica).

---

## 5. Mapa de domínios

| Módulo | Domínio | Entidades |
|---|---|---|
| `organizacao` | Estrutura Organizacional | `Unidade`, `ConfiguracaoSistema` |
| `usuarios` | Usuários e Autenticação | `User` |
| `pedagogico` | Cadastros Pedagógicos | `Curso`, `Nivel` |
| `academico` | Estrutura Acadêmica | `PeriodoLetivo`, `Turma`, `TemaAula` |
| `pessoas` | Pessoas | `Aluno`, `SituacaoEscolar` |
| `matriculas` | Matrículas e Movimentações | `Inscricao`, `Transferencia` |
| `calendario` | Calendário Acadêmico | `DiaBloqueado`, `DiaBloqueadoTurma` |
| `aulas` | Frequência e Aulas | `Frequencia`, `RegistroAula` |
| `conselho` | Conselho de Classe | `PeriodoConselho`, `PerguntaConselho`, `OpcaoProximaTurma`, `ConselhoClasse`, `ConselhoResposta` |
| `atendimento` | Atendimento | `Atendimento` |
| `servico_social` | Serviço Social | `AgendaServicoSocial`, `RespostaFormulario` |
| `auditoria` | Auditoria | `LogAcao` |
| `legado` | Legado | `Registro` |

---

## 6. Diagramas ER por domínio

### 6.1 Núcleo organizacional e usuários

```mermaid
erDiagram
    UNIDADE ||--o{ USER : possui
    UNIDADE ||--o{ CONFIGURACAO_SISTEMA : parametriza
    UNIDADE ||--o{ CURSO : catalogo
    UNIDADE ||--o{ PERIODO_LETIVO : organiza
    UNIDADE ||--o{ TURMA : agrupa
    UNIDADE ||--o{ ALUNO : matricula
```

### 6.2 Estrutura acadêmica

```mermaid
erDiagram
    PERIODO_LETIVO ||--o{ TURMA : contem
    CURSO          ||--o{ TURMA : oferta
    CURSO          ||--o{ TEMA_AULA : planeja
    USER           ||--o{ TURMA : leciona
    TURMA          ||--o{ REGISTRO_AULA : registra
    TEMA_AULA      ||--o{ REGISTRO_AULA : tema
```

### 6.3 Alunos, matrículas e frequência

```mermaid
erDiagram
    ALUNO ||--|| SITUACAO_ESCOLAR : detalha
    ALUNO ||--o{ INSCRICAO : possui
    TURMA ||--o{ INSCRICAO : recebe
    ALUNO ||--o{ FREQUENCIA : registra
    TURMA ||--o{ FREQUENCIA : pauta
    ALUNO ||--o{ TRANSFERENCIA : movimenta
```

### 6.4 Conselho de classe

```mermaid
erDiagram
    PERIODO_LETIVO ||--o{ PERIODO_CONSELHO : agenda
    PERIODO_CONSELHO ||--o{ CONSELHO_CLASSE : contem
    TURMA ||--o{ CONSELHO_CLASSE : avalia
    ALUNO ||--o{ CONSELHO_CLASSE : avaliado
    CONSELHO_CLASSE ||--o{ CONSELHO_RESPOSTA : possui
    PERGUNTA_CONSELHO ||--o{ CONSELHO_RESPOSTA : responde
    OPCAO_PROXIMA_TURMA ||--o{ CONSELHO_CLASSE : destino
```

### 6.5 Serviço social, atendimento e auditoria

```mermaid
erDiagram
    ALUNO ||--o{ ATENDIMENTO : recebe
    ALUNO ||--o{ RESPOSTA_FORMULARIO : responde
    USER  ||--o{ AGENDA_SERVICO_SOCIAL : cria
    USER  ||--o{ LOG_ACAO : gera
```

---

## 7. Dicionário de dados

> Tipos lógicos (independentes do SGBD). `NOT NULL` indicado explicitamente.
> Defaults descritos quando relevantes.

### 7.1 `unidade`

| Coluna | Tipo | Nulo | Default | Descrição |
|---|---|---|---|---|
| id | int | não | auto | PK |
| nome | varchar(100) | não | — | Nome da unidade |
| ativo | bool | não | true | Soft delete |

### 7.2 `configuracao_sistema`

| Coluna | Tipo | Nulo | Default | Descrição |
|---|---|---|---|---|
| id | int | não | auto | PK |
| chave | varchar(50) | não | — | **UNIQUE** global |
| valor | varchar(100) | sim | — | Valor serializado |
| descricao | varchar(255) | sim | — | Texto explicativo |
| unidade_id | int | sim | — | NULL = global |

### 7.3 `user`

| Coluna | Tipo | Nulo | Default | Descrição |
|---|---|---|---|---|
| id | int | não | auto | PK |
| name | varchar(100) | não | — | Nome completo |
| email | varchar(120) | não | — | **UNIQUE** global |
| password | varchar(200) | sim | — | Hash Werkzeug; NULL para AD |
| role | varchar(20) | não | — | admin / pedagogico / professor / secretaria / serviço social / pendente |
| is_active | bool | não | true | Conta ativa |
| is_ad_user | bool | não | false | Autenticação por domínio |
| unidade_id | int | sim | — | FK → unidade |
| first_login | bool | sim | true | Força troca de senha |
| google_id | varchar(100) | sim | — | **UNIQUE**, indexado |
| google_email | varchar(120) | sim | — | E-mail Google |

### 7.4 `curso`

| Coluna | Tipo | Nulo | Default | Descrição |
|---|---|---|---|---|
| id | int | não | auto | PK |
| nome | varchar(150) | não | — | Nome do curso |
| descricao | varchar(300) | sim | — | Descrição |
| carga_horaria | int | sim | — | Horas previstas |
| ativo | bool | não | true | Soft delete |
| unidade_id | int | não | — | FK → unidade |
| created_at | timestamp | sim | now | Auditoria |

### 7.5 `nivel`

| Coluna | Tipo | Nulo | Default | Descrição |
|---|---|---|---|---|
| id | int | não | auto | PK |
| nome | varchar(100) | não | — | **UNIQUE** global |
| ativo | bool | não | true | Soft delete |
| unidade_id | int | sim | — | FK → unidade |

### 7.6 `periodo_letivo`

| Coluna | Tipo | Nulo | Default | Descrição |
|---|---|---|---|---|
| id | int | não | auto | PK |
| nome | varchar(150) | não | — | Nome |
| data_inicio | date | não | — | Início |
| data_fim | date | não | — | Fim |
| centro_custo | varchar(150) | sim | — | Centro de custo |
| estimativa_alunos | int | não | 0 | Planejamento |
| ativo | bool | não | true | Soft delete |
| unidade_id | int | não | — | FK → unidade |
| created_at | timestamp | sim | now | Auditoria |
| updated_at | timestamp | sim | onupdate | Auditoria |

### 7.7 `turma`

| Coluna | Tipo | Nulo | Default | Descrição |
|---|---|---|---|---|
| id | int | não | auto | PK |
| nome | varchar(100) | não | — | Nome |
| ativo | bool | não | true | Soft delete |
| data_inicio | varchar(10) | sim | — | **String** YYYY-MM-DD |
| data_fim | varchar(10) | sim | — | **String** YYYY-MM-DD |
| hora_inicio | varchar(5) | sim | — | **String** HH:MM |
| hora_fim | varchar(5) | sim | — | **String** HH:MM |
| dias_semana | varchar(20) | sim | — | CSV (ex.: "Segunda,Quarta") |
| programa | varchar(50) | sim | — | Esporte, Profissionalizante… |
| turno | varchar(20) | sim | — | Manhã, Tarde, Noite |
| centro_custo | varchar(150) | sim | — | — |
| ordenacao | int | sim | — | Ordem de exibição |
| unidade_id | int | sim | — | FK → unidade |
| periodo_letivo_id | int | sim | — | FK → periodo_letivo |
| curso_id | int | sim | — | FK → curso |
| professor_id | int | sim | — | FK → user |
| avaliacao_inicial | text | sim | — | Parecer |
| avaliacao_percurso | text | sim | — | Parecer |
| avaliacao_final | text | sim | — | Parecer |
| conselho_concluido | bool | não | false | Flag de encerramento |

### 7.8 `tema_aula`

| Coluna | Tipo | Nulo | Default | Descrição |
|---|---|---|---|---|
| id | int | não | auto | PK |
| curso_id | int | sim | — | FK → curso |
| turma_id | int | sim | — | **LEGADO** — FK → turma |
| unidade_id | int | sim | — | FK → unidade |
| titulo | varchar(200) | sim | — | Título |
| programa | varchar(50) | sim | — | Programa |
| ativo | bool | não | true | Soft delete |
| data | varchar(20) | sim | — | String |
| ordem | int | não | 0 | Sequência didática |

### 7.9 `aluno`

| Coluna | Tipo | Nulo | Default | Descrição |
|---|---|---|---|---|
| id | int | não | auto | PK |
| nome | varchar(100) | não | — | Nome civil |
| nome_social | varchar(100) | sim | — | Nome social (preferir em UI) |
| ativo | bool | não | true | Soft delete |
| data_nascimento | date | sim | — | — |
| foto_path | varchar(255) | sim | — | Caminho relativo |
| escolaridade_json | text | sim | — | JSON cru (via property) |
| identificacao_json | text | sim | — | JSON cru (via property) |
| socioeconomico_json | text | sim | — | JSON cru (via property) |
| diversidade_json | text | sim | — | JSON cru (via property) |
| cpf | varchar(20) | sim | — | — |
| rg | varchar(50) | sim | — | — |
| whatsapp | varchar(30) | sim | — | — |
| email | varchar(120) | sim | — | — |
| nivel | varchar(20) | sim | — | Básico / Intermediário / Avançado |
| created_by_id | int | sim | — | FK → user |
| created_by_name | varchar(100) | sim | — | Snapshot do nome |
| created_at | timestamp | sim | now | Auditoria |
| unidade_id | int | sim | — | FK → unidade |

**Properties derivadas (não persistem):** `matricula`, `foto`, `idade`,
`escolaridade_json`, `identificacao_json`, `socioeconomico_json`,
`diversidade_json`.

### 7.10 `situacao_escolar`

| Coluna | Tipo | Nulo | Default | Descrição |
|---|---|---|---|---|
| id | int | não | auto | PK |
| aluno_id | int | não | — | **UNIQUE** — FK → aluno |
| unidade_id | int | sim | — | FK → unidade |
| escolaridade | varchar(40) | sim | — | — |
| ensino_superior_periodo | int | sim | — | — |
| escolaridade_outro | varchar(150) | sim | — | Quando "Outro" |
| status | varchar(20) | sim | — | — |
| status_outro | varchar(150) | sim | — | Quando "Outro" |
| nome_instituicao | varchar(200) | sim | — | Indexado com unidade |
| tipo_instituicao | varchar(20) | sim | — | — |
| bolsista | bool | não | false | — |
| tipo_instituicao_outro | varchar(150) | sim | — | Quando "Outro" |
| turno | varchar(20) | sim | — | — |
| turno_outro | varchar(100) | sim | — | Quando "Outro" |
| created_at | timestamp | não | now | Auditoria |
| updated_at | timestamp | não | now/onupdate | Auditoria |

### 7.11 `inscricoes`

| Coluna | Tipo | Nulo | Default | Descrição |
|---|---|---|---|---|
| id | int | não | auto | PK |
| aluno_id | int | não | — | FK → aluno |
| turma_id | int | não | — | FK → turma |
| nivel | varchar(30) | sim | — | Nível na turma |
| ativo | bool | não | true | Vínculo atual |
| data_inicio | date | não | now | Início |
| data_desativacao | timestamp | sim | — | Quando desativado |
| motivo_desativacao | varchar(50) | sim | — | Motivo |

> Múltiplas linhas com o mesmo (aluno, turma) são permitidas por design —
> servem para histórico de ativação/desativação.

### 7.12 `transferencia`

| Coluna | Tipo | Nulo | Default | Descrição |
|---|---|---|---|---|
| id | int | não | auto | PK |
| aluno_id | int | não | — | FK → aluno |
| turma_origem_id | int | não | — | FK → turma |
| turma_destino_id | int | não | — | FK → turma |
| data_transferencia | timestamp | não | now | — |
| observacoes | text | sim | — | — |
| unidade_id | int | não | — | FK → unidade |

### 7.13 `dia_bloqueado`

| Coluna | Tipo | Nulo | Default | Descrição |
|---|---|---|---|---|
| id | int | não | auto | PK |
| data | date | não | — | Dia bloqueado |
| tipo | varchar(50) | não | — | FERIADO / ATIVIDADE_PEDAGOGICA / REUNIAO_PAIS / ATIVIDADE_INTERNA / MANUTENCAO |
| descricao | varchar(200) | sim | — | — |
| periodo_letivo_id | int | não | — | FK → periodo_letivo |
| unidade_id | int | não | — | FK → unidade |
| criado_por_id | int | sim | — | FK → user |
| created_at | timestamp | sim | now | — |

### 7.14 `dia_bloqueado_turma`

| Coluna | Tipo | Nulo | Default | Descrição |
|---|---|---|---|---|
| id | int | não | auto | PK |
| turma_id | int | não | — | FK → turma |
| data | varchar(10) | não | — | **String** YYYY-MM-DD |
| unidade_id | int | sim | — | FK → unidade |
| criado_por_id | int | sim | — | FK → user |
| created_at | timestamp | sim | now | — |

**UNIQUE** (`turma_id`, `data`).

### 7.15 `frequencia`

| Coluna | Tipo | Nulo | Default | Descrição |
|---|---|---|---|---|
| id | int | não | auto | PK |
| aluno_id | int | não | — | FK → aluno |
| turma_id | int | não | — | FK → turma |
| data | varchar(20) | não | — | **String** YYYY-MM-DD |
| conceito | varchar(1) | sim | — | A/B/C/D/F/J |
| unidade_id | int | sim | — | FK → unidade |

**Property híbrida:** `presente` (A/B/C/D).

### 7.16 `registro_aula`

| Coluna | Tipo | Nulo | Default | Descrição |
|---|---|---|---|---|
| id | int | não | auto | PK |
| turma_id | int | não | — | FK → turma |
| data | varchar(20) | não | — | **String** YYYY-MM-DD |
| tema_id | int | sim | — | FK → tema_aula |
| observacoes | text | sim | — | — |
| instrutor_id | int | sim | — | FK → user |
| created_at | timestamp | sim | now | — |
| unidade_id | int | sim | — | FK → unidade |

### 7.17 `periodo_conselho`

| Coluna | Tipo | Nulo | Default | Descrição |
|---|---|---|---|---|
| id | int | não | auto | PK |
| nome | varchar(100) | não | — | — |
| data_inicio | date | não | — | — |
| data_fim | date | não | — | — |
| conselho_final | bool | não | false | Encerramento |
| periodo_letivo_id | int | não | — | FK → periodo_letivo |
| unidade_id | int | não | — | FK → unidade |

### 7.18 `conselho_pergunta`

| Coluna | Tipo | Nulo | Default | Descrição |
|---|---|---|---|---|
| id | int | não | auto | PK |
| etapa | varchar(20) | sim | — | INICIAL / PERCURSO / FINAL |
| tipo | varchar(20) | sim | ALUNO | TURMA / ALUNO |
| texto | text | não | — | — |
| opcoes | text | sim | — | Alternativas serializadas |
| ativo | bool | não | true | Soft delete |

### 7.19 `opcao_proxima_turma`

| Coluna | Tipo | Nulo | Default | Descrição |
|---|---|---|---|---|
| id | int | não | auto | PK |
| nome | varchar(100) | não | — | — |
| ativo | bool | não | true | — |

### 7.20 `conselho_classe`

| Coluna | Tipo | Nulo | Default | Descrição |
|---|---|---|---|---|
| id | int | não | auto | PK |
| turma_id | int | não | — | FK → turma |
| aluno_id | int | não | — | FK → aluno |
| etapa | varchar(20) | não | — | INICIAL / PERCURSO / FINAL |
| data_inicio | date | sim | — | — |
| data_fim | date | sim | — | — |
| concluido | bool | não | false | — |
| instrutor_id | int | sim | — | FK → user |
| observacao | text | sim | — | — |
| situacao_final | varchar(30) | sim | — | Aprovado / Reprovado por Falta / Desistente / Evadido |
| proxima_turma_id | int | sim | — | FK → opcao_proxima_turma |
| unidade_id | int | sim | — | FK → unidade |

### 7.21 `conselho_resposta`

| Coluna | Tipo | Nulo | Default | Descrição |
|---|---|---|---|---|
| id | int | não | auto | PK |
| conselho_id | int | não | — | FK → conselho_classe |
| aluno_id | int | não | — | FK → aluno |
| pergunta_id | int | não | — | FK → conselho_pergunta |
| resposta | text | sim | — | — |
| observacao | text | sim | — | — |
| unidade_id | int | sim | — | FK → unidade |

### 7.22 `atendimento`

| Coluna | Tipo | Nulo | Default | Descrição |
|---|---|---|---|---|
| id | int | não | auto | PK |
| aluno_id | int | não | — | FK → aluno |
| setor | varchar(50) | não | pedagogico | **LEGADO** — não usar em novas features |
| data_atendimento | date | não | — | — |
| resumo | varchar(255) | sim | — | — |
| dados | json | não | {} | Conteúdo variável |
| atendido_por_id | int | sim | — | FK → user |
| atendido_por_nome | varchar(150) | sim | — | Snapshot |
| unidade_id | int | sim | — | FK → unidade |
| created_at | timestamp | sim | now | — |
| updated_at | timestamp | sim | now/onupdate | — |

### 7.23 `agenda_servico_social`

| Coluna | Tipo | Nulo | Default | Descrição |
|---|---|---|---|---|
| id | int | não | auto | PK |
| titulo | varchar(200) | não | — | — |
| categoria | varchar(100) | não | — | — |
| data | date | não | — | — |
| hora | varchar(5) | não | — | HH:MM |
| localizacao | varchar(255) | sim | — | — |
| descricao | text | sim | — | — |
| google_event_id | varchar(255) | sim | — | ID no Google |
| participantes_emails | text | sim | — | CSV de e-mails |
| user_id | int | não | — | FK → user |
| data_criacao | timestamp | sim | now | — |

### 7.24 `respostas_formulario`

| Coluna | Tipo | Nulo | Default | Descrição |
|---|---|---|---|---|
| id | int | não | auto | PK |
| tipo_formulario | varchar(50) | não | — | Identificador do formulário |
| aluno_id | int | sim | — | FK → aluno |
| usuario_id | int | não | — | FK → user |
| dados | json | não | — | Respostas |
| created_at | timestamp | sim | now | — |
| updated_at | timestamp | sim | now/onupdate | — |

### 7.25 `log_acao`

| Coluna | Tipo | Nulo | Default | Descrição |
|---|---|---|---|---|
| id | int | não | auto | PK |
| data_hora | timestamp | sim | now | — |
| usuario_id | int | sim | — | FK → user |
| usuario_nome | varchar(100) | sim | — | Snapshot |
| acao | varchar(255) | sim | — | Texto da ação |
| detalhes | text | sim | — | Contexto |
| ip | varchar(50) | sim | — | IP de origem |
| unidade_id | int | sim | — | FK → unidade |

### 7.26 `registro` (LEGADO)

| Coluna | Tipo | Nulo | Default | Descrição |
|---|---|---|---|---|
| id | int | não | auto | PK |
| educador_id | int | não | — | FK → user |
| turma | varchar(100) | sim | — | Nome (string livre) |
| mes | varchar(20) | sim | — | — |
| turno | varchar(20) | sim | — | — |
| dados_json | text | sim | — | JSON cru |
| criado_em | timestamp | sim | now | — |
| unidade_id | int | sim | — | FK → unidade |

---

## 8. Regras de negócio transversais

### 8.1 Frequência
- Conceitos `A`,`B`,`C`,`D` = presente.
- `F` = falta.
- `J` = justificada — **não entra no numerador nem no denominador**.
- Fórmula: `freq = presentes / (presentes + faltas) * 100`.

### 8.2 Conselho de Classe
- Etapas: `INICIAL`, `PERCURSO`, `FINAL`.
- `conselho_final=True` marca o conselho que define situação final.
- `situacao_final` só deve ser preenchida quando `concluido=True`.

### 8.3 Inscrição
- Um aluno pode ter **múltiplas linhas** em `inscricoes` para a mesma turma
  (histórico de ativação/desativação).
- Sempre considerar `ativo=True` como o vínculo atual.
- Ao desativar: preencher `data_desativacao` e `motivo_desativacao`.

### 8.4 Calendário
- `DiaBloqueado` afeta **todas** as turmas do período letivo.
- `DiaBloqueadoTurma` cria **exceção**: a turma tem aula naquele dia.

### 8.5 Aluno
- `matricula` = `{id:05d}.{ano_atual}` — sempre derivada, nunca persistida.
- `idade` = calculada em runtime a partir de `data_nascimento`.
- `nome_social` deve prevalecer sobre `nome` em todas as telas e relatórios.

### 8.6 Atendimento
- Campo `setor` **não deve ser usado** em novas features (legado).
- O fluxo atual é exclusivamente pedagógico.

---

## 9. Convenções de código

### 9.1 Estrutura do pacote
- Um arquivo por domínio (ver §2).
- `__init__.py` reexporta tudo — é o único ponto de entrada público.
- `base.py` centraliza imports e convenções (não define modelos).

### 9.2 Nomenclatura
- Tabelas em **português**, plural quando coleção (`inscricoes`, `respostas_formulario`).
- Colunas em **snake_case**.
- FKs: `<entidade>_id`.
- Backrefs existentes **não devem ser renomeados sem migration**.

### 9.3 Boas práticas
- Não colocar lógica de negócio pesada nos models — preferir services.
- `freq_geral` e `alunos_enturmados` são exceções históricas.
- Preferir `back_populates` em código novo (ver §10).
- Novas colunas de data/hora devem usar `db.DateTime` (não string).
- Novos enums devem usar `db.Enum` ou constantes, não strings soltas.
- Nunca importar modelos por caminho interno fora do pacote.

---

## 10. Dívida técnica e roadmap

### 10.1 Datas/horas como string
**Onde:** `Turma.data_inicio/data_fim/hora_inicio/hora_fim`, `Frequencia.data`,
`RegistroAula.data`, `DiaBloqueadoTurma.data`, `TemaAula.data`.

**Impacto:** dificulta filtros SQL por intervalo, ordenação e comparações.

**Plano:**
1. Adicionar colunas novas (`data_new date`, `hora_new time`).
2. Backfill a partir das strings.
3. Trocar o código para as colunas novas.
4. Remover colunas antigas.

### 10.2 `backref` em vez de `back_populates`
**Onde:** quase todos os relacionamentos.

**Impacto:** dificulta leitura e refatoração (ambos os lados implícitos).

**Plano:** migrar gradualmente por domínio, mantendo os mesmos nomes de backref.

### 10.3 Falta de mixins para auditoria
**Onde:** `created_at`, `updated_at`, `ativo`, `unidade_id` repetidos em N modelos.

**Impacto:** duplicação e risco de inconsistência.

**Plano:** criar `TimestampMixin`, `SoftDeleteMixin`, `TenantMixin` em
`app/models/base.py` (requer refatoração cuidadosa pelas variações de
`nullable`/`default`).

### 10.4 Ausência de índices em FKs muito consultadas
**Onde:** `aluno_id`, `turma_id`, `unidade_id`, `periodo_letivo_id` em tabelas
grandes (`frequencia`, `inscricoes`, `log_acao`).

**Plano:** auditar planos de execução e adicionar índices conforme gargalos.

### 10.5 Falta de constraints de unicidade de negócio
**Onde:** `ConselhoClasse` (turma, aluno, etapa), `ConfiguracaoSistema`
(chave, unidade), `Nivel` (nome, unidade), `Curso` (nome, unidade).

**Plano:** adicionar `UniqueConstraint` compostas via migration.