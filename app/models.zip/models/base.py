"""
================================================================================
BASE.PY - Imports comuns e convenções do pacote de modelos
================================================================================

Este arquivo NÃO define modelos. Ele existe para:

    1. Centralizar os imports que todos os submódulos do pacote usam
       (`db`, `get_local_now`, `datetime`, `date`, etc.).
    2. Documentar as convenções do pacote.
    3. Ser o ponto único de extensão para futuros mixins (TimestampMixin,
       SoftDeleteMixin, TenantMixin) sem quebrar os módulos existentes.

CONVENÇÕES
----------
- Cada módulo do pacote cobre UM domínio de negócio (ver MER.md §4).
- Dentro do pacote, importe os outros modelos pelo caminho completo
  (ex.: `from app.models.pessoas import Aluno`) para evitar importação
  parcial durante o carregamento de `__init__.py`.
- `app/models/__init__.py` reexporta tudo — é o ponto de entrada público.
- Toda decisão de schema deve ser refletida em MER.md.
================================================================================
"""

# --- Imports de biblioteca padrão -------------------------------------------------
import json
from datetime import datetime, date, timezone
from typing import List, Optional

# --- Imports de terceiros ---------------------------------------------------------
from flask_login import UserMixin
from sqlalchemy import select
from sqlalchemy.ext.hybrid import hybrid_property
from werkzeug.security import generate_password_hash, check_password_hash

# --- Imports internos da aplicação ------------------------------------------------
from app.database import db
from app.utils.timezone import get_local_now


__all__ = [
    # Biblioteca padrão
    'json', 'datetime', 'date', 'timezone', 'List', 'Optional',
    # Terceiros
    'UserMixin', 'select', 'hybrid_property',
    'generate_password_hash', 'check_password_hash',
    # Aplicação
    'db', 'get_local_now',
]